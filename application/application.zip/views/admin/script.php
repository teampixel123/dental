<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../assets/js/jquery-3.4.1.min.js" type="text/javascript"></script>
<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- <script src="../assets/js/owl.carousel.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script> -->
<script src="../assets/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="../assets/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../assets/js/dataTables.bootstrap4.min.js"></script>
<script src="../assets/js/dental.js" type="text/javascript"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#blog_list1').DataTable();
  } );
</script>
